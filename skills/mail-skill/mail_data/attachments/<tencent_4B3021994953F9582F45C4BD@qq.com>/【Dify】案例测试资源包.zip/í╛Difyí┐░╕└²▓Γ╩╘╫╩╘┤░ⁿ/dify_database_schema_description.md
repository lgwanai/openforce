# 数据库表结构说明
**字段定义**

| column_name | data_type | nullable | key | description |
| --- | --- | --- | --- | --- |
| order_id | TEXT | NO | PK | 订单编号 |
| transaction_time | TEXT | NO |  | 交易时间 |
| car_model | TEXT | NO |  | 车型 |
| sales_region | TEXT | NO |  | 销售区域 |
| province | TEXT | NO |  | 省份 |
| city | TEXT | NO |  | 城市 |
| dealer_name | TEXT | NO |  | 经销商名称 |
| dealer_id | TEXT | NO |  | 经销商 ID |
| dealer_sales_region | TEXT | NO |  | 经销商所属销售大区 |
| deal_price_rmb | INTEGER | NO |  | 成交价，单位：元 |
| sales_revenue_rmb | INTEGER | NO |  | 销售收入，单位：元 |
| sales_channel | TEXT | NO |  | 销售渠道 |
| powertrain_type | TEXT | NO |  | 动力类型，取值：BEV / ICE / PHEV |


